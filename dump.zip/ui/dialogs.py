from pathlib import Path

from PyQt6.QtCore import Qt, pyqtSignal
from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QSpinBox,
    QWidget,
    QTabWidget,
    QTableWidget,
    QTableWidgetItem,
    QHeaderView,
    QVBoxLayout,
)


class SettingsDialog(QDialog):
    """Окно настроек SQPaint. Новые разделы добавляются отдельными вкладками."""

    apply_requested = pyqtSignal(dict)

    def __init__(self, settings: dict, parent=None):
        super().__init__(parent)
        from copy import deepcopy
        from PyQt6.QtWidgets import (
            QCheckBox, QComboBox, QHBoxLayout, QPushButton, QTabWidget,
        )

        self.setWindowTitle("Настройки")
        self.setModal(True)
        self.resize(460, 300)
        self._settings = deepcopy(settings if isinstance(settings, dict) else {})
        view = self._settings.setdefault("view", {})

        root = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        root.addWidget(self.tabs)

        # Вкладка «Вид». При добавлении других разделов создавайте здесь
        # отдельные вкладки и сохраняйте их параметры в соответствующих ключах.
        view_page = QWidget(self)
        view_form = QFormLayout(view_page)

        self.theme_combo = QComboBox(view_page)
        self.theme_combo.addItem("Тёмная", "dark")
        self.theme_combo.addItem("Светлая", "light")
        theme_index = self.theme_combo.findData(view.get("theme", "dark"))
        self.theme_combo.setCurrentIndex(max(0, theme_index))
        view_form.addRow("Тема:", self.theme_combo)

        self.layer_panel_check = QCheckBox("Показывать панель слоёв", view_page)
        self.layer_panel_check.setChecked(view.get("layer_panel_visible", True))
        view_form.addRow(self.layer_panel_check)

        self.toolbar_check = QCheckBox("Показывать панель инструментов", view_page)
        self.toolbar_check.setChecked(view.get("toolbar_visible", True))
        view_form.addRow(self.toolbar_check)

        self.zoom_check = QCheckBox("Показывать управление масштабом", view_page)
        self.zoom_check.setChecked(view.get("zoom_control_visible", True))
        view_form.addRow(self.zoom_check)

        self.welcome_check = QCheckBox(
            "Показывать окно приветствия при запуске", view_page
        )
        self.welcome_check.setChecked(view.get("show_welcome", True))
        view_form.addRow(self.welcome_check)

        self.tabs.addTab(view_page, "Вид")

        buttons_layout = QHBoxLayout()
        buttons_layout.addStretch()
        self.cancel_button = QPushButton("Отмена", self)
        self.apply_button = QPushButton("Применить", self)
        self.exit_button = QPushButton("Выход", self)
        buttons_layout.addWidget(self.cancel_button)
        buttons_layout.addWidget(self.apply_button)
        buttons_layout.addWidget(self.exit_button)
        root.addLayout(buttons_layout)

        self.cancel_button.clicked.connect(self.reject)
        self.apply_button.clicked.connect(self._apply)
        self.exit_button.clicked.connect(self._apply_and_close)

    def _collect_settings(self) -> dict:
        """Собирает значения всех вкладок в структуру настроек."""
        view = self._settings.setdefault("view", {})
        view.update({
            "theme": self.theme_combo.currentData(),
            "layer_panel_visible": self.layer_panel_check.isChecked(),
            "toolbar_visible": self.toolbar_check.isChecked(),
            "zoom_control_visible": self.zoom_check.isChecked(),
            "show_welcome": self.welcome_check.isChecked(),
        })
        return self._settings

    def _apply(self) -> None:
        self.apply_requested.emit(self._collect_settings())

    def _apply_and_close(self) -> None:
        self._apply()
        self.accept()


class NewProjectDialog(QDialog):
    """Диалог параметров нового проекта."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Новый проект")
        self.setModal(True)

        self.name_edit = QLineEdit("Новый проект", self)

        self.width_spin = QSpinBox(self)
        self.width_spin.setRange(1, 8192)
        self.width_spin.setValue(1920)
        self.width_spin.setSuffix(" px")

        self.height_spin = QSpinBox(self)
        self.height_spin.setRange(1, 8192)
        self.height_spin.setValue(1080)
        self.height_spin.setSuffix(" px")

        form = QFormLayout(self)
        form.addRow("Название:", self.name_edit)
        form.addRow("Ширина:", self.width_spin)
        form.addRow("Высота:", self.height_spin)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def get_values(self) -> tuple[str, int, int]:
        return (
            self.name_edit.text().strip(),
            self.width_spin.value(),
            self.height_spin.value(),
        )


class CanvasSizeDialog(QDialog):
    """Диалог изменения размеров документа."""

    def __init__(self, width: int, height: int, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Размер холста")
        self.setModal(True)
        self.setMinimumWidth(300)

        self.width_spin = QSpinBox(self)
        self.width_spin.setRange(1, 8192)
        self.width_spin.setValue(width)
        self.width_spin.setSuffix(" px")

        self.height_spin = QSpinBox(self)
        self.height_spin.setRange(1, 8192)
        self.height_spin.setValue(height)
        self.height_spin.setSuffix(" px")

        form = QFormLayout(self)
        form.addRow("Ширина:", self.width_spin)
        form.addRow("Высота:", self.height_spin)
        form.addRow(QLabel(
            "При уменьшении холста содержимое за его границами будет обрезано."
        ))

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok
            | QDialogButtonBox.StandardButton.Cancel,
            parent=self,
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Применить")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        form.addRow(buttons)

    def get_size(self) -> tuple[int, int]:
        return self.width_spin.value(), self.height_spin.value()


class DeleteLayerDialog(QDialog):
    """Диалог подтверждения удаления слоя."""

    def __init__(self, layer_name: str, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Удаление слоя")
        self.setModal(True)

        layout = QFormLayout(self)
        layout.addRow(QLabel(
            f'Вы действительно хотите удалить слой «{layer_name}»?'
        ))

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Yes
            | QDialogButtonBox.StandardButton.No,
            parent=self,
        )
        buttons.button(QDialogButtonBox.StandardButton.Yes).setText("Удалить")
        buttons.button(QDialogButtonBox.StandardButton.No).setText("Отмена")
        buttons.button(QDialogButtonBox.StandardButton.No).setDefault(True)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addRow(buttons)

# ---------------------------------------------------------------------------
# Функции-обёртки: всё, что окно показывает пользователю, живёт здесь.
# ---------------------------------------------------------------------------

PROJECT_EXTENSION = ".sqlite"
PROJECT_FILTER = "Проекты SQPaint (*.sqlite)"


# --- Запросы данных у пользователя ---

def ask_new_project(parent: QWidget | None = None) -> tuple[str, int, int] | None:
    """Показывает диалог нового проекта.

    Возвращает (название, ширина, высота) или None, если пользователь
    отменил диалог или ввёл пустое название.
    """
    dialog = NewProjectDialog(parent)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None

    name, width, height = dialog.get_values()
    if not name:
        QMessageBox.warning(
            parent,
            "Некорректное название",
            "Введите название проекта.",
        )
        return None

    return name, width, height


def ask_save_project_path(parent: QWidget | None, name: str) -> str:
    """Выбор пути для нового проекта. Пустая строка — пользователь отменил."""
    path, _ = QFileDialog.getSaveFileName(
        parent,
        "Создать проект",
        f"{name}{PROJECT_EXTENSION}",
        PROJECT_FILTER,
    )
    if path and not path.lower().endswith(PROJECT_EXTENSION):
        path += PROJECT_EXTENSION
    return path


def ask_open_project_path(parent: QWidget | None = None) -> str:
    """Выбор существующего проекта. Пустая строка — пользователь отменил."""
    path, _ = QFileDialog.getOpenFileName(
        parent,
        "Открыть проект",
        "",
        f"{PROJECT_FILTER};;Все файлы (*)",
    )
    return path


def ask_canvas_size(
    parent: QWidget | None, width: int, height: int
) -> tuple[int, int] | None:
    """Возвращает новые размеры холста или None при отмене."""
    dialog = CanvasSizeDialog(width, height, parent)
    if dialog.exec() != QDialog.DialogCode.Accepted:
        return None
    return dialog.get_size()


def confirm_delete_layer(parent: QWidget | None, layer_name: str) -> bool:
    """Спрашивает подтверждение удаления слоя. True — удалить."""
    dialog = DeleteLayerDialog(layer_name, parent)
    return dialog.exec() == QDialog.DialogCode.Accepted


# --- Сообщения ---

def show_file_exists(parent: QWidget | None = None) -> None:
    QMessageBox.warning(
        parent,
        "Файл уже существует",
        "Выберите другое имя или другое расположение файла. "
        "Существующие файлы не перезаписываются.",
    )


def show_create_error(parent: QWidget | None, error: Exception) -> None:
    QMessageBox.critical(
        parent,
        "Не удалось создать проект",
        f"Проект не удалось создать.\n\n{error}",
    )


def show_open_error(parent: QWidget | None, error: Exception) -> None:
    QMessageBox.critical(
        parent,
        "Не удалось открыть проект",
        f"Файл не удалось загрузить. Возможно, он повреждён "
        f"или не является проектом SQPaint.\n\n{error}",
    )


def show_save_error(parent: QWidget | None, error: Exception) -> None:
    QMessageBox.critical(
        parent,
        "Ошибка сохранения",
        f"Не удалось сохранить проект.\n\n{error}",
    )


def show_last_layer_info(parent: QWidget | None = None) -> None:
    QMessageBox.information(
        parent,
        "Удаление слоя",
        "В проекте должен остаться хотя бы один слой.",
    )


# --- Диалоги файловых операций ---

def ask_save_as_path(parent: QWidget | None = None, name: str = "Проект") -> str:
    path, _ = QFileDialog.getSaveFileName(
        parent, "Сохранить проект как", f"{name}.sqlite",
        f"{PROJECT_FILTER};;Все файлы (*)",
    )
    if path and not path.lower().endswith(PROJECT_EXTENSION):
        path += PROJECT_EXTENSION
    return path


def ask_import_image_path(parent: QWidget | None = None) -> str:
    path, _ = QFileDialog.getOpenFileName(
        parent, "Импортировать изображение",
        "", "Изображения (*.png *.jpg *.jpeg *.bmp *.webp);;Все файлы (*)",
    )
    return path


def ask_export_image_path(parent: QWidget | None, image_format: str) -> str:
    ext = image_format.lower()
    path, _ = QFileDialog.getSaveFileName(
        parent, f"Экспортировать {ext.upper()}",
        f"Изображение.{ext}",
        f"{ext.upper()} (*.{ext})",
    )
    if path and not path.lower().endswith(f".{ext}"):
        path += f".{ext}"
    return path


class FileInfoDialog(QDialog):
    """Окно просмотра содержимого SQLite-файла проекта."""

    TABLES = (
        ("project", "project"),
        ("layers", "layers"),
        ("logs", "logs"),
    )

    def __init__(self, database_path: str, parent=None):
        super().__init__(parent)
        import sqlite3

        self.setWindowTitle("О файле проекта")
        self.resize(900, 520)

        layout = QVBoxLayout(self)
        self.tabs = QTabWidget(self)
        layout.addWidget(self.tabs)

        try:
            connection = sqlite3.connect(
                f"file:{database_path}?mode=ro", uri=True
            )
            try:
                for tab_title, table_name in self.TABLES:
                    table = QTableWidget(self)
                    table.setEditTriggers(
                        QTableWidget.EditTrigger.NoEditTriggers
                    )
                    table.setAlternatingRowColors(True)
                    table.setSelectionBehavior(
                        QTableWidget.SelectionBehavior.SelectRows
                    )
                    self._load_table(connection, table, table_name)
                    self.tabs.addTab(table, tab_title)
            finally:
                connection.close()
        except sqlite3.Error as error:
            QMessageBox.critical(
                self, "Ошибка чтения файла",
                f"Не удалось прочитать содержимое SQLite-файла.\\n\\n{error}",
            )

    @staticmethod
    def _load_table(connection, widget: QTableWidget, table_name: str) -> None:
        cursor = connection.execute(f'SELECT * FROM "{table_name}"')
        columns = [item[0] for item in cursor.description or ()]
        rows = cursor.fetchall()

        widget.setColumnCount(len(columns))
        widget.setHorizontalHeaderLabels(columns)
        widget.setRowCount(len(rows))

        for row_index, row in enumerate(rows):
            for column_index, value in enumerate(row):
                if isinstance(value, bytes):
                    display = f"<BLOB: {len(value)} байт>"
                elif value is None:
                    display = "NULL"
                else:
                    display = str(value)
                widget.setItem(
                    row_index, column_index, QTableWidgetItem(display)
                )

        header = widget.horizontalHeader()
        header.setSectionResizeMode(QHeaderView.ResizeMode.ResizeToContents)
        header.setStretchLastSection(True)


def show_file_info(parent: QWidget | None, database_path: str) -> None:
    dialog = FileInfoDialog(database_path, parent)
    dialog.exec()


class AboutDialog(QDialog):
    """Информационное окно о программе SQPaint."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("О программе SQPaint")
        self.setModal(True)
        self.setFixedWidth(380)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(24, 20, 24, 20)
        layout.setSpacing(10)

        logo_label = QLabel(self)
        logo_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        logo_path = Path(__file__).resolve().parents[1] / "logo.png"
        pixmap = QPixmap(str(logo_path))
        if not pixmap.isNull():
            logo_label.setPixmap(
                pixmap.scaled(
                    160, 160,
                    Qt.AspectRatioMode.KeepAspectRatio,
                    Qt.TransformationMode.SmoothTransformation,
                )
            )
            layout.addWidget(logo_label)

        title = QLabel("<h2 style='margin: 0'>SQPaint</h2>", self)
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(title)

        description = QLabel(
            "Растровый графический редактор с поддержкой слоёв. "
            "Проекты сохраняются в формате SQLite (.sqlite).",
            self,
        )
        description.setWordWrap(True)
        description.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(description)

        technology = QLabel("Создано на Python и PyQt6", self)
        technology.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(technology)

        project_link = QLabel(
            '<a href="https://github.com/RolicsVin/sqpaint">'
            "Исходный код на GitHub</a>",
            self,
        )
        project_link.setOpenExternalLinks(True)
        project_link.setAlignment(Qt.AlignmentFlag.AlignCenter)
        layout.addWidget(project_link)

        buttons = QDialogButtonBox(
            QDialogButtonBox.StandardButton.Ok, parent=self
        )
        buttons.button(QDialogButtonBox.StandardButton.Ok).setText("Закрыть")
        buttons.accepted.connect(self.accept)
        layout.addWidget(buttons)


def show_about(parent: QWidget | None = None) -> None:
    """Показывает окно «О программе»."""
    AboutDialog(parent).exec()
